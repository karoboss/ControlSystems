clc;
clear all;
close all;
pkg load control;
pkg load signal;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 1ST EXERSICE %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%Time vector
t = [0:0.1:50];
s = tf('s');
f1 = 1/((2*s+1)^2);
f2 = 1/((s+1)^2);
f3 = 1/((s+1)*(5*s+1));
f4 = 1/((0.1*s+1)*(10*s+1));
% Graph of step function of each function
%Step for f1
figure()
step(f1);
title('Step Response for  function 1');
xlabel('time(s)');
ylabel('Amplitude');
xlim([0 10]);
%Step for f2
figure()
step(f2);
title('Step Response for  function 2');
xlabel('time(s)');
ylabel('Amplitude');
xlim([0 6]);
%Step for f3
figure()
step(f3);
title('Step Response for  function 3');
xlabel('time(s)');
ylabel('Amplitude');
xlim([0 30]);
%Step for f4
figure()
step(f4);
title('Step Response for  function 4');
xlabel('time(s)');
ylabel('Amplitude');
xlim([0 30]);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 2 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%ZN METHOD
% Calculate transfer function based on T1,T2,T3,Ks
Ks = 1.0;
T1 = 2.0;
T2 = 2.0;
T3 = 2.0;
s = tf('s');
H = Ks*(1/(T1*s+1))*(1/(T2*s+1))*(1/(T3*s+1))
G = feedback(H,1);
figure();
step(H);
title('Step Response for transfer function');
xlabel('time(s)');
ylabel('Amplitude');
xlim([0 30]);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% PLOTS %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%K = 1;
for Kp=1:0.5:8
    H1 = (Kp*H)/(1+Kp*H);
    figure; % create a new figure for each value of Kp
    step(H1);
    title(['Step Response for Kp = ', num2str(Kp)])
    xlabel('time(s)');
    ylabel('Amplitude');
    xlim([0 250]);
    end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% TCRIT CALCULATION %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

Kptest=8;
Htest = (Kptest*H)/(1+Kptest*H);
[y, t] = step(Htest); % Calculate the step response of H1[tpeaks, ~] = findpeaks(y);
[tpeaks, ~] = findpeaks(y); % Find the peaks in the step response
tp = zeros(length(tpeaks),1); % Initialize an array to store the times of the peaks
j = 1;
for i=2:length(y)-1 % Loop through the step response to find the times of the peaks
    if (y(i) > y(i-1) && y(i) > y(i+1))
        tp(j) = t(i);
        j = j + 1;
    end
end
Tcrit = tp(2) - tp(1); % Calculate the period of oscillation
disp(['The period of oscillation at Kp = 8 is ', num2str(Tcrit), ' seconds.']);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% ZN METHOD CONTROLLERS %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Kpcrit=8 Tcrit=7.33
%P controler 0.5*8=4

%For P controller: K = 4 , no Ti or Td
Kcrit=8;
Kp_p_zn = 0.5*Kcrit;
Ti = inf;
Td = 0;
c_zn_p = pidstd(Kp_p_zn,Ti,Td)
h_zn_p = c_zn_p*H
figure;
step(feedback(c_zn_p*H,1));
title(['System response with P controller with K= ',num2str(Kp_p_zn),',']);
xlabel('time(s)');
ylabel('Amplitude');
legend('H-zn-p');

%PI controler k=3.6 Ti=6.23
Kp_pi_zn = 3.6;
Ti = 6.23;
Td = 0;
c_zn_pi = pidstd(Kp_pi_zn,Ti,Td)
h_zn_pi = c_zn_pi*H
figure;
step(feedback(c_zn_pi*H,1));
title(['System response with Pi controller with K= ',num2str(Kp_pi_zn),' and Ti=',num2str(Ti),'.']);
xlabel('time(s)');
ylabel('Amplitude');
legend('H-zn-pi');

%PID controler k=3.6 Ti=6.23
Kp_pid_zn = 4.8;
Ti = 3.615;
Td = 0.8796;
c_zn_pid = pidstd(Kp_pid_zn,Ti,Td)
h_zn_pid = c_zn_pid*H
figure;
step(feedback(c_zn_pid*H,1));
title(['System response with Pid controller with K= ',num2str(Kp_pid_zn),' and Ti=',num2str(Ti),'and Td=',num2str(Td),'.']);
xlabel('time(s)');
ylabel('Amplitude');
legend('H-zn-pid');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% CHR METHOD START %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure();
step(H);
xlim([0 100]);
title('Step Response for transfer function chr method(no feedback)');
xlabel('time(s)');
ylabel('Amplitude');
%take the nominator and denominator
[nominator, denominator] = tfdata(H);
denominator_coeeficients = denominator{1};
%take the roots
denominator_roots = roots(denominator_coeeficients);
%Find the order from roots
order = sum(real(denominator_roots) < 0);
disp(['The Order of the system is: ', num2str(order)]);
%Time constants from the system
Tu = 1.7;
Tg = 6.7;
K=1;
T1chr = 1 / (((1 / (2 * (1 / sqrt(Tu * Tg))) * (1 / Tu + 1 / Tg)) * (1 / sqrt(Tu * Tg))));
T2chr = 1 / (1 / sqrt(Tu * Tg));
disp(['The T1chr quadratic constant is ', num2str(T1chr), ' seconds.']);
disp(['The T2chr quadratic constant is ', num2str(T2chr), ' seconds.']);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 0 OVERSHOOT %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%P controller: Kp = 1.182
k_chr0_p = 1.182;
Ti = inf;
Td = 0;
c_chr0_p = pidstd(k_chr0_p,Ti,Td)
H_chr0_p = c_chr0_p*H
figure()
step(feedback(c_chr0_p*H,1));
title(['System response with P controller 0% overshoot with K = ',num2str(k_chr0_p),',']);
xlabel('time(s)');
ylabel('Amplitude');
legend('H-chr0-p');

%PI controller: Kp = 1.379, Ti = 8.04
k_chr0_pi = 1.379;
Ti = 8.04;
Td = 0;
c_chr0_pi =pidstd(k_chr0_pi,Ti,Td)
H_chr0_pi =c_chr0_pi*H
figure()
step(feedback(c_chr0_pi*H,1));
title(['System response with Pi controller 0% with K= ',num2str(k_chr0_pi),' and Ti=',num2str(Ti),'.']);
xlabel('time(s)');
ylabel('Amplitude');
legend('H-chr0-pi');

%PID controller: Kp =  2.364, Ti = 6.7, Td = 0.85
k_chr0_pid = 2.364;
Ti = 8.04;
Td = 0.85
c_chr0_pid =pidstd(k_chr0_pid,Ti,Td)
H_chr0_pid = c_chr0_pid*H
figure()
step(feedback(c_chr0_pid*H,1));
title('PID controller and setpoint 0% overshoot')
title(['System response with Pid controller with K= ',num2str(k_chr0_pid),' and Ti=',num2str(Ti),' and Td=',num2str(Td),'.']);
xlabel('time(s)');
ylabel('Amplitude');
legend('H-chr0-pid');


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 20 OVERSHOOT %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%P controller: Kp = 2.758
k_chr20_p = 2.758;
Ti = inf;
Td = 0;
c_chr20_p=pidstd(k_chr20_p,Ti,Td)
H_chr20_p = c_chr20_p*H
figure()
step(feedback(c_chr20_p*H,1));
title(['System response with P controller 20% overshoot with K = ',num2str(k_chr20_p),',']);
xlabel('time(s)');
ylabel('Amplitude');
legend('H-chr20-p');


%PI controller: Kp = 2.364, Ti = 6.7
k_chr20_pi = 2.364;
Ti = 6.7;
Td = 0;
c_chr20_pi = pidstd(k_chr20_pi,Ti,Td)
H_chr20_pi = c_chr20_pi*H
figure()
step(feedback(c_chr20_pi*H,1));
title(['System response with Pi controller 20% with K= ',num2str(k_chr20_pi),' and Ti=',num2str(Ti),'.']);
xlabel('time(s)');
ylabel('Amplitude');
legend('H-chr20-pi');

%PID controller: Kp =  3.744, Ti = 9.38, Td = 0.799
k_chr20_pid = 3.744;
Ti = 9.38;
Td = 0.799;
c_chr20_pid = pidstd(k_chr20_pid,Ti,Td)
H_chr20_pid = c_chr20_pid*H
figure()
step(feedback(c_chr20_pid*H,1));
title(['System response with Pid controller 20% with K= ',num2str(k_chr20_pid),' and Ti=',num2str(Ti),' and Td=',num2str(Td),'.']);
xlabel('time(s)');
ylabel('Amplitude');
legend('H-chr20-pid');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%TEST%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
##%%Tu and Tg calculation
##[y,t] = step(H);
##damp_ratio = sqrt(log(1/0.707)^2/(pi^2+log(1/0.707)^2));e


